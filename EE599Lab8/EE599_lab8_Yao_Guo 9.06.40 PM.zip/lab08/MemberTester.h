//
// `MemberTester.h`
//
#ifndef EE599_LAB8_MEMBERTESTER_H
#define EE599_LAB8_MEMBERTESTER_H
class MemberTester {
public:
    void runTests();
    void testConstructors();
    void testReadFrom();
    void testWriteTo();
};

#endif //EE599_LAB8_MEMBERTESTER_H