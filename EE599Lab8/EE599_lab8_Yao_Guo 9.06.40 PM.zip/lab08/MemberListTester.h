//
// MemberListTester.h
//

#ifndef EE599_LAB8_MEMBERLISTTESTER_H
#define EE599_LAB8_MEMBERLISTTESTER_H
 
class MemberListTester {
public:
    void runTests();
    void testConstructors();
    void testSearchByUsername();
    void testSearchByEmail();
    void testSearchByYear();
};
 
 
#endif //EE599_LAB8_MEMBERLISTTESTER_H